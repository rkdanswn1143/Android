package com.example.testmovie;

import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    private ImageView posterImageView;
    private TextView titleTextView, originalTitleTextView, overviewTextView, releaseDateTextView;
    private EditText etReview;
    private Button btnSubmitReview;
    private LinearLayout reviewContainer;
    private String movieId; // 영화 ID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        posterImageView = findViewById(R.id.posterImageView);
        titleTextView = findViewById(R.id.titleTextView);
        originalTitleTextView = findViewById(R.id.originalTitleTextView);
        overviewTextView = findViewById(R.id.overviewTextView);
        releaseDateTextView = findViewById(R.id.releaseDateTextView);
        etReview = findViewById(R.id.etReview);
        btnSubmitReview = findViewById(R.id.btnSubmitReview);
        reviewContainer = findViewById(R.id.reviewContainer);

        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        String original_title = intent.getStringExtra("original_title");
        String poster_path = intent.getStringExtra("poster_path");
        String overview = intent.getStringExtra("overview");
        String release_date = intent.getStringExtra("release_date");
        movieId = intent.getStringExtra("movie_id"); // 영화 ID

        titleTextView.setText(title);
        originalTitleTextView.setText(original_title);
        overviewTextView.setText(overview);
        releaseDateTextView.setText(release_date);

        Glide.with(this)
                .load("https://image.tmdb.org/t/p/w500" + poster_path)
                .thumbnail(0.1f)
                .centerCrop()
                .into(posterImageView);

        displayReviews();

        btnSubmitReview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String review = etReview.getText().toString();
                if (!review.isEmpty()) {
                    // 사용자 정보 가져오기
                    SharedPreferences preferences = getSharedPreferences("user_session", MODE_PRIVATE);
                    String username = preferences.getString("username", "");
                    String name = preferences.getString("name", "");

                    DatabaseHelper dbHelper = new DatabaseHelper(DetailActivity.this);
                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    ContentValues values = new ContentValues();
                    values.put("movie_id", movieId);
                    values.put("review", review);
                    values.put("username", username); // 사용자 아이디 저장
                    values.put("name", name); // 사용자 이름 저장
                    db.insert("reviews", null, values);
                    db.close();
                    etReview.setText("");
                    displayReviews();
                } else {
                    Toast.makeText(DetailActivity.this, "리뷰를 입력하세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void displayReviews() {
        reviewContainer.removeAllViews();
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT review, name FROM reviews WHERE movie_id=?", new String[]{movieId});
        if (cursor.moveToFirst()) {
            do {
                String review = cursor.getString(0);
                String name = cursor.getString(1);
                TextView reviewTextView = new TextView(this);
                reviewTextView.setText(name + ": " + review);
                reviewTextView.setTextSize(16f);
                reviewTextView.setPadding(0, 4, 0, 4);
                reviewContainer.addView(reviewTextView);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
    }
}
